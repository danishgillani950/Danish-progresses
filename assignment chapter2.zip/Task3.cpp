#include <iostream>
using namespace std;
int main() {
    double gallons, mpg;
    cout << "Enter fuel tank capacity (gallons): ";
    cin >> gallons;
    cout << "Enter miles per gallon: ";
    cin >> mpg;
    cout << "Miles without refueling: " << gallons * mpg << endl;
    return 0;
}
#include <iostream>
using namespace std;
int main() {
    double size;
    cout << "Enter hard drive size (GB): ";
    cin >> size;
    double bytes = size * 1000000000;
    cout << "Actual capacity: " << bytes / (1024 * 1024 * 1024) << " GB" << endl;
    return 0;
}
#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double milk, costPerL, profitPerCarton;
    const double cartonSize = 3.78;
    cout << "Enter milk produced (liters): ";
    cin >> milk;
    cout << "Enter cost per liter: ";
    cin >> costPerL;
    cout << "Enter profit per carton: ";
    cin >> profitPerCarton;
    int cartons = round(milk / cartonSize);
    double cost = milk * costPerL, profit = cartons * profitPerCarton;
    cout << "Cartons: " << cartons << "\nCost: $" << cost << "\nProfit: $" << profit << endl;
    return 0;
}
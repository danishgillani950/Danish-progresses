#include <iostream>
using namespace std;
int main() {
    double m1, m2, d;
    const double G = 6.67e-11;
    cout << "Enter masses and distance: ";
    cin >> m1 >> m2 >> d;
    cout << "Force: " << G * m1 * m2 / (d * d) << " N" << endl;
    return 0;
}
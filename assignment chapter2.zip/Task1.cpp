#include <iostream>
using namespace std;
int main() {
    double a, b, c, d, e;
    cout << "Enter five test scores: ";
    cin >> a >> b >> c >> d >> e;
    cout << "Average score: " << (a + b + c + d + e) / 5 << endl;
    return 0;
}
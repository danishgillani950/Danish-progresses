#include <iostream>
using namespace std;
int main() {
    double rate, hours;
    cout << "Enter hourly pay rate: ";
    cin >> rate;
    cout << "Enter hours worked: ";
    cin >> hours;
    double income = rate * hours;
    double afterTax = income * 0.86;
    cout << "Income before tax: $" << income;
    cout << "\nIncome after tax: $" << afterTax;
    cout << "\nClothes: $" << afterTax * 0.1;
    cout << "\nSchool supplies: $" << afterTax * 0.01;
    cout << "\nSavings bonds: $" << afterTax * 0.25;
    cout << "\nParents’ bonds: $" << afterTax * 0.25 * 0.5 << endl;
    return 0;
}
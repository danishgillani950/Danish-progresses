#include <iostream>
using namespace std;
int main() {
    int shares;
    double buy, sell;
    const double rate = 0.015;
    cout << "Enter shares, buy price, sell price: ";
    cin >> shares >> buy >> sell;
    double invested = shares * buy;
    double received = shares * sell;
    double charges = invested * rate + received * rate;
    double net = (received - received * rate) - (invested + invested * rate);
    cout << "Invested: $" << invested;
    cout << "\nService charges: $" << charges;
    cout << "\nNet " << (net >= 0 ? "Gain: $" : "Loss: $") << (net >= 0 ? net : -net);
    cout << "\nAmount received: $" << received - received * rate << endl;
    return 0;
}
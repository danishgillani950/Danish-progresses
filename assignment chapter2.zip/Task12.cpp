#include <iostream>
using namespace std;
int main() {
    double fixed, percent, cost, minAdd, maxAdd;
    cout << "Enter fixed commission: ";
    cin >> fixed;
    cout << "Enter commission %: ";
    cin >> percent;
    cout << "Enter purchasing cost: ";
    cin >> cost;
    cout << "Enter min add: ";
    cin >> minAdd;
    cout << "Enter max add: ";
    cin >> maxAdd;
    double minPrice = cost + minAdd, maxPrice = cost + maxAdd;
    double minComm = fixed + minPrice * percent / 100;
    double maxComm = fixed + maxPrice * percent / 100;
    cout << "Min price: $" << minPrice << "\nMax price: $" << maxPrice;
    cout << "\nCommission range: $" << minComm << " - $" << maxComm << endl;
    return 0;
}
#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double bag;
    cout << "Enter bag capacity (lbs): ";
    cin >> bag;
    cout << "Bags needed: " << ceil(2205 / bag) << endl;
    return 0;
}
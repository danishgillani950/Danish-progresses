#include <iostream>
using namespace std;
int main() {
    int sec;
    cout << "Enter elapsed time in seconds: ";
    cin >> sec;
    cout << sec / 3600 << " hours " << (sec % 3600) / 60 << " minutes " << sec % 60 << " seconds" << endl;
    return 0;
}
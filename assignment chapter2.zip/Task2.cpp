#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double a, b, c, d, e;
    cout << "Enter five decimal numbers: ";
    cin >> a >> b >> c >> d >> e;
    cout << "Rounded sum: " << round(a + b + c + d + e) << endl;
    return 0;
}
#include <iostream>
using namespace std;
int main() {
    const double PI = 3.141593;
    double r;
    cout << "Enter radius: ";
    cin >> r;
    cout << "Area: " << PI * r * r << "\nCircumference: " << 2 * PI * r << endl;
    return 0;
}
#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double milk;
    const double cartonSize = 3.78, costPerLiter = 0.38, profitPerCarton = 0.27;
    cout << "Enter milk produced (liters): ";
    cin >> milk;
    int cartons = round(milk / cartonSize);
    double cost = milk * costPerLiter, profit = cartons * profitPerCarton;
    cout << "Cartons: " << cartons << "\nCost: $" << cost << "\nProfit: $" << profit << endl;
    return 0;
}
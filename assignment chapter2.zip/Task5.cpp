#include <iostream>
using namespace std;
int main() {
    double price, markup, tax;
    cout << "Enter original price: ";
    cin >> price;
    cout << "Enter markup %: ";
    cin >> markup;
    cout << "Enter sales tax %: ";
    cin >> tax;
    double sell = price + price * markup / 100;
    double salesTax = sell * tax / 100;
    cout << "Selling price: $" << sell << "\nFinal price: $" << sell + salesTax << endl;
    return 0;
}
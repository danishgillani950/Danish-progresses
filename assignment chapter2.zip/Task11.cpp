#include <iostream>
using namespace std;
int main() {
    int q, d, n;
    cout << "Enter quarters, dimes, nickels: ";
    cin >> q >> d >> n;
    cout << "Total pennies: " << q * 25 + d * 10 + n * 5 << endl;
    return 0;
}